
"""
Sample package
"""

import json
import logging
import logging.config
from pprint import pformat


LOGGER = logging.getLogger(__name__)


def setup_logging(level):
    logging_cfg = {
        'version': 1,
        # 'formatters': {
        #     'default': {
        #         'class': 'logging.Formatter',
        #     },
        # },
        'handlers': {
            'console': {
                'class': 'logging.StreamHandler',
            },
        },
        'root': {
            'level': level,
            'handlers': ['console'],
        },
        # 'disable_existing_loggers': False,
    }

    logging.config.dictConfig(logging_cfg)


setup_logging('INFO')


def mainfn(event, context):
    LOGGER.info('Got event: %s', pformat(event))

    # See:
    # https://docs.aws.amazon.com/lambda/latest/dg/python-context-object.html
    context_str = f"""
Log group name: {context.log_group_name}
Log stream name: {context.log_stream_name}
AWS request id: {context.aws_request_id}
Mem limit MB: {context.memory_limit_in_mb}
""".format(context)
    LOGGER.info('Got context: %s', pformat(context_str))

    LOGGER.info('-' * 80)

    remaining = context.get_remaining_time_in_millis()

    return {
        'statusCode': 200,
        'body': json.dumps({
            'message': 'Remaining time: {}'.format(remaining),
        }),
    }
